package entity;

import exceptions.WrongPhoneNumberException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import repository.UserRepository;
import utill.Utill;

import java.util.*;

@NoArgsConstructor
@AllArgsConstructor
public class User {
    private String phoneNumber;
    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber.matches("[+]\\d{12}")) {
            this.phoneNumber = phoneNumber;
        } else {
            throw new WrongPhoneNumberException();
        }
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
}
