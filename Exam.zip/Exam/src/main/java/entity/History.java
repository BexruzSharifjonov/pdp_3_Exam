package entity;

import lombok.Data;


@Data
public class History {
    private String message;
    private String from;
    private String to;
}
